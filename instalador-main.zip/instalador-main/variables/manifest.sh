#!/bin/bash

source "${PROJECT_ROOT}"/variables/_app.sh
source "${PROJECT_ROOT}"/variables/_general.sh
source "${PROJECT_ROOT}"/variables/_background.sh
source "${PROJECT_ROOT}"/variables/_fonts.sh
